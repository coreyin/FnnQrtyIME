package com.caixnet.fnnqrtyime.config

object KeyboardTypeKeys {
    lateinit var isKeyboardType:KeyboardType

    //val myKeysTextArray : ArrayList<String> = ArrayList() <List<String>(5)


    val fnn10HanyinList = ArrayList<List<String>>()
    val fnn10EnglishList = ArrayList<List<String>>()
    val fnn10NumberList = ArrayList<List<String>>()
    val fnn10SymbolList = ArrayList<List<String>>()

    //// fnn10
    // ㄲㄸㅓㄹㅌㅡㅜㅣㅗㅍ
    val fnn10HanyinTextLine1 = listOf<String> ("ㄲ", "ㄸ", "ㅓ", "ㄹ", "ㅌ", "ㅡ", "ㅜ", "ㅣ", "ㅗ", "ㅍ")
    val fnn10HanyinTextLine2 = listOf<String> ("ㅏ", "ㅅ", "ㄷ", "ㅥ", "ㄱ", "ㅎ", "ㅉ", "ㅋ", "ㅇ")
    val fnn10HanyinTextLine3 = listOf<String> ("123", "ㅈ", "ㅆ", "ㅊ", "ㅂ", "ㅃ", "ㄴ", "ㅁ","DEL")
    val fnn10HanyinTextLine4 = listOf<String> ("ABC", ",", "☯", "SPACE", ".", "ENTER")

    // QWERTYUIOP
    val fnn10EnglishTextLine1 = listOf<String> ("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val fnn10EnglishTextLine2 = listOf<String> ("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val fnn10EnglishTextLine3 = listOf<String> ("CAPS", "z", "x", "c", "v", "b", "n", "m", "DEL")
    val fnn10EnglishTextLine4 = listOf<String> ("ㄱㄴㄷ", ",", "☯", "SPACE", ".", "ENTER")

    // 12344567890
    val fnn10NumberTextLine1 = listOf<String>  ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val fnn10NumberTextLine2 = listOf<String>  ("+", "-", "*", "/", "%", "^", "=", "(", ")")
    val fnn10NumberTextLine3 = listOf<String>  ("!@#", "?", "!", "&", "|", ":", "<", ">", "DEL")
    val fnn10NumberTextLine4 = listOf<String>  ("ㄱㄴㄷ",",","☯","SPACE",".","ENTER")


    // !@#$%^&*()
    val fnn10SymbolTextLine1 = listOf<String>   ("!", "@", "#", "$", "%", "^", "&", "*", "(", ")")
    val fnn10SymbolTextLine2 = listOf<String>   ("\"","`",  "~", "|", "\\",  "[", "]", "{", "}")
    val fnn10SymbolTextLine3 = listOf<String>   ("123", "\'", ",", "_", ".", ";", "<", ">", "DEL")
    val fnn10SymbolTextLine4 = listOf<String> ("ㄱㄴㄷ",",","☯","SPACE",".","ENTER")



    init{
        ////
        //
        fnn10HanyinList.add(fnn10HanyinTextLine1)
        fnn10HanyinList.add(fnn10HanyinTextLine2)
        fnn10HanyinList.add(fnn10HanyinTextLine3)
        fnn10HanyinList.add(fnn10HanyinTextLine4)
        //
        fnn10EnglishList.add(fnn10EnglishTextLine1)
        fnn10EnglishList.add(fnn10EnglishTextLine2)
        fnn10EnglishList.add(fnn10EnglishTextLine3)
        fnn10EnglishList.add(fnn10EnglishTextLine4)
        //
        fnn10NumberList.add(fnn10NumberTextLine1)
        fnn10NumberList.add(fnn10NumberTextLine2)
        fnn10NumberList.add(fnn10NumberTextLine3)
        fnn10NumberList.add(fnn10NumberTextLine4)
        //
        fnn10SymbolList.add(fnn10SymbolTextLine1)
        fnn10SymbolList.add(fnn10SymbolTextLine2)
        fnn10SymbolList.add(fnn10SymbolTextLine3)
        fnn10SymbolList.add(fnn10SymbolTextLine4)

    }
    //
    @JvmStatic
    fun get10Keyboard(isKbdType: KeyboardType): ArrayList<List<String>> {
        var fnn10Kbd: ArrayList<List<String>>
        when (isKbdType) {
            KeyboardType.FnnQtryKor -> {
                fnn10Kbd = fnn10HanyinList
            }
            KeyboardType.FnnQtryEng -> {
                fnn10Kbd = fnn10EnglishList
            }
            KeyboardType.FnnQtryNum -> {
                fnn10Kbd = fnn10NumberList
            }
            KeyboardType.FnnQrtySym -> {
                fnn10Kbd = fnn10SymbolList
            }
            else -> {
                fnn10Kbd = fnn10HanyinList
            }
        }
        return fnn10Kbd
    }

}