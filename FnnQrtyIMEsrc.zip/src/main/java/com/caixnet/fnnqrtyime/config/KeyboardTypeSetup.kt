package com.caixnet.fnnqrtyime.config

object KeyboardTypeSetup {
    var isKeyboardType:KeyboardType

    init {
        isKeyboardType = KeyboardType.FnnQtryKor
    }

    //获取键盘语言状态
    @JvmStatic
    fun get(): KeyboardType {
        return isKeyboardType
    }

    //set keyboard type state
    @JvmStatic
    fun set(mKbdType: KeyboardType) {
        isKeyboardType = mKbdType
    }
}