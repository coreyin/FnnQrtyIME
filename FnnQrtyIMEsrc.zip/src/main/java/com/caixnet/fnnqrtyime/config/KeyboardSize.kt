package com.caixnet.fnnqrtyime.config

object KeyboardSize {
    var mHeightRate:Float

    init {
        mHeightRate = 0.9F
    }

    fun setSizeRate(siz: Float) {
        mHeightRate = siz
    }

    fun getSizeRage():Float {
        return mHeightRate
    }
}