package com.caixnet.fnnqrtyime.config

enum class KeyboardType {
    // CnzKrIME keyboard type 체인지한글 키보드 탛프
    FnnQtryEng,
    FnnQtryKor,
    FnnQtryNum,
    FnnQrtySym,

}