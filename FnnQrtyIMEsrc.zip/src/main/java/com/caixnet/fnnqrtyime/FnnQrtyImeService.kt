package com.caixnet.fnnqrtyime

import android.annotation.SuppressLint
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.caixnet.fnnqrtyime.keyboard.FnnQrtyEng
import com.caixnet.fnnqrtyime.keyboard.FnnQrtyKor
import com.caixnet.fnnqrtyime.keyboard.FnnQrtyNum
import com.caixnet.fnnqrtyime.keyboard.FnnQrtySym
import com.caixnet.fnnqrtyime.config.KeyboardType
import com.caixnet.fnnqrtyime.config.KeyboardTypeSetup

//import com.caixnet.fnnqrtyime.R
//import java.util.*
import com.caixnet.fnnqrtyime.R.id.keyboard_frame

class FnnQrtyImeService : InputMethodService() {

    // 当前候选词表
//    private var suggestionlist : MutableList<String?>? = null
    // 词典数据
//    private var data : Hashtable<String, List<String>>? = null
    //键盘布局
    private lateinit var keyboardView: LinearLayout
    //键盘内容容器
    lateinit var keyboardFrame: FrameLayout

    lateinit var fnn10KbdKor: FnnQrtyKor
    lateinit var fnn10KbdEng: FnnQrtyEng
    lateinit var fnn10KbdNum: FnnQrtyNum
    lateinit var fnn10KbdSym: FnnQrtySym

    override fun onCreate() {
        super.onCreate()

        fnn10KbdKor = FnnQrtyKor(applicationContext, layoutInflater, keyboardInterationListener)
        fnn10KbdEng = FnnQrtyEng(applicationContext, layoutInflater, keyboardInterationListener)
        fnn10KbdNum = FnnQrtyNum(applicationContext, layoutInflater, keyboardInterationListener)
        fnn10KbdSym = FnnQrtySym(applicationContext, layoutInflater, keyboardInterationListener)

        fnn10KbdSym.inputConnection = currentInputConnection
        fnn10KbdSym.init()


        fnn10KbdNum.inputConnection = currentInputConnection
        fnn10KbdNum.init()

        fnn10KbdEng.inputConnection = currentInputConnection
        fnn10KbdEng.init()
        
        fnn10KbdKor.inputConnection = currentInputConnection
        fnn10KbdKor.init()
        
    }
    
    @SuppressLint("InflateParams")
    override fun onCreateInputView(): View {
        super.onCreateInputView()
        
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as LinearLayout
        keyboardFrame = keyboardView.findViewById(keyboard_frame)
        
        return keyboardView
    }

    override fun updateInputViewShown() {
        super.updateInputViewShown()
        currentInputConnection.finishComposingText()

        if (currentInputEditorInfo.inputType == EditorInfo.TYPE_CLASS_NUMBER) {
            keyboardFrame.removeAllViews()
            KeyboardTypeSetup.set(KeyboardTypeSetup.get())
        } else {
            keyboardInterationListener.changeMode(KeyboardTypeSetup.get())
        }
        
    }
    
    private val keyboardInterationListener by lazy {

        // Log.i("CAI", "keyboardInterationListener")
        object : KeyboardInterationListener {
            override fun changeMode(mode: KeyboardType) {
//                currentInputConnection.finishComposingText()
                when (mode) {
                    //
                    KeyboardType.FnnQtryKor -> {
                        keyboardFrame.removeAllViews()
                        KeyboardTypeSetup.set(KeyboardType.FnnQtryKor)
                        fnn10KbdKor.inputConnection = currentInputConnection
                        // Log.i("CAI", "KeyboardInterationListener:")
                        keyboardFrame.addView(fnn10KbdKor.getLayout(KeyboardType.FnnQtryKor))
                        //                // Log.i("CAI", "input service KbQfHanyin Setup.KeyboardType"+ getKeyboardType())
                    }
                    //
                    KeyboardType.FnnQtryEng -> {
                        keyboardFrame.removeAllViews()
                        KeyboardTypeSetup.set(KeyboardType.FnnQtryEng)
                        fnn10KbdEng.inputConnection = currentInputConnection
                        keyboardFrame.addView(fnn10KbdEng.getLayout(KeyboardType.FnnQtryEng))
                        //                // Log.i("CAI", "input service KbQfHanyin Setup.KeyboardType"+ getKeyboardType())
                    }
                    //
                    KeyboardType.FnnQtryNum -> {
                        keyboardFrame.removeAllViews()
                        KeyboardTypeSetup.set(KeyboardType.FnnQtryNum)
                        fnn10KbdNum.inputConnection = currentInputConnection
                        keyboardFrame.addView(fnn10KbdNum.getLayout(KeyboardType.FnnQtryNum))
                        //                // Log.i("CAI", "input service KbQfHanyin Setup.KeyboardType"+ getKeyboardType())
                    }
                    //
                    KeyboardType.FnnQrtySym -> {
                        keyboardFrame.removeAllViews()
                        KeyboardTypeSetup.set(KeyboardType.FnnQrtySym)
                        fnn10KbdSym.inputConnection = currentInputConnection
                        keyboardFrame.addView(fnn10KbdSym.getLayout(KeyboardType.FnnQrtySym))
                        //                // Log.i("CAI", "input service KbQfHanyin Setup.KeyboardType"+ getKeyboardType())
                    }


//                    else -> {
//                        //                    // Log.i("CAI", " input Else--")
//                        keyboardFrame.removeAllViews()
//
//                    }


                }
            }


        }

    }
    
    
}