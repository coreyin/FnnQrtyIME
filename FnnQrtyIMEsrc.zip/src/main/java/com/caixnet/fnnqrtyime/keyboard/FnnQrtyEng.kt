package com.caixnet.fnnqrtyime.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.inputmethodservice.Keyboard
import android.media.AudioManager
import android.os.*
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.view.children
import com.caixnet.fnnqrtyime.KeyboardInterationListener
import com.caixnet.fnnqrtyime.R
import com.caixnet.fnnqrtyime.code.FnnHanyinCode
import com.caixnet.fnnqrtyime.config.KeyboardSize
import com.caixnet.fnnqrtyime.config.KeyboardType
import com.caixnet.fnnqrtyime.config.KeyboardTypeKeys
import com.caixnet.fnnqrtyime.config.KeyboardTypeSetup
import java.util.*
import kotlin.collections.ArrayList

class FnnQrtyEng constructor(
    var context: Context,
    var layoutInflater: LayoutInflater,
    var keyboardInterationListener: KeyboardInterationListener
) {
    // QFWMBXJ , QWERTYUIOP
    private lateinit var keyboardLayout: LinearLayout
    var isHanyin: Boolean = true
    var isCaps: Boolean = false
    lateinit var imm: InputMethodManager
    //
    var buttons: MutableList<Button> = mutableListOf<Button>()
    lateinit var hanyinCode: FnnHanyinCode
    lateinit var vibrator: Vibrator
    lateinit var sharedPreferences: SharedPreferences
    var inputConnection: InputConnection? = null
    var sound = 0
    var vibrate = 0
    // 定义元音键盘
    lateinit var yButton: Button
    lateinit var iButton: Button
    lateinit var aButton: Button
    lateinit var eButton: Button
    lateinit var oButton: Button
    lateinit var uButton: Button
    //
    lateinit var capsButton: Button
    lateinit var langButton: Button
    lateinit var delButton: Button
    lateinit var spaceButton: Button
    lateinit var enterButton: Button
    //
    var myKeysText = ArrayList<List<String>>()
    val layoutLines = ArrayList<LinearLayout>()
    //
    var downView: View? = null
    var capsView: ImageView? = null
    var langView: ImageView? = null
    //初始化键盘
    //初始化键盘
    fun init() {

        //初始化键盘布局
        keyboardLayout = layoutInflater.inflate(R.layout.keyboard_qrty, null) as LinearLayout
        vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        sharedPreferences = context.getSharedPreferences("setting", Context.MODE_PRIVATE)
        val height = sharedPreferences.getInt("keyboardHeight", 180)
        val config = context.resources.configuration
        sound = sharedPreferences.getInt("keyboardSound", -1)
        vibrate = sharedPreferences.getInt("keyboardVibrate", -1)
        //设置键盘高度
        val layoutLine1  = keyboardLayout.findViewById<LinearLayout>(R.id.first_line)
        val layoutLine2  = keyboardLayout.findViewById<LinearLayout>(R.id.second_line)
        val layoutLine3  = keyboardLayout.findViewById<LinearLayout>(R.id.third_line)
        val layoutLine4  = keyboardLayout.findViewById<LinearLayout>(R.id.fourth_line)
        //特殊键盘值定义特定变量
        yButton = layoutLine1.findViewById<View>(R.id.action_key_y).findViewById<Button>(R.id.key_button)
//        // Log.i("CAI", "layout3-ybutton "+yButton.toString())
        iButton = layoutLine1.findViewById<View>(R.id.action_key_i).findViewById<Button>(R.id.key_button)
        aButton = layoutLine2.findViewById<View>(R.id.action_key_a).findViewById<Button>(R.id.key_button)
        eButton = layoutLine1.findViewById<View>(R.id.action_key_e).findViewById<Button>(R.id.key_button)
        oButton = layoutLine1.findViewById<View>(R.id.action_key_o).findViewById<Button>(R.id.key_button)
        uButton = layoutLine1.findViewById<View>(R.id.action_key_u).findViewById<Button>(R.id.key_button)

        capsView = layoutLine3.findViewById<View>(R.id.action_key_caps).findViewById<ImageView>(R.id.spacial_key)
        capsButton = layoutLine3.findViewById<View>(R.id.action_key_caps).findViewById<Button>(R.id.key_button)
        delButton = layoutLine3.findViewById<View>(R.id.action_key_del).findViewById<Button>(R.id.key_button)
        spaceButton = layoutLine4.findViewById<View>(R.id.action_key_space).findViewById<Button>(R.id.key_button)
        langButton = layoutLine4.findViewById<View>(R.id.action_key_lang).findViewById<Button>(R.id.key_button)
        enterButton = layoutLine4.findViewById<View>(R.id.action_key_enter).findViewById<Button>(R.id.key_button)



        //按照横竖摆列定义键盘高度
        //
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            layoutLine1.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine2.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine3.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine4.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )

        } else {
            layoutLine1.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine2.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine3.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )
            layoutLine4.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (height * KeyboardSize.getSizeRage()).toInt()
            )

        }

//        myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardType.FnnKbdKor)

        //
        layoutLines.clear()
        layoutLines.add(layoutLine1)
        layoutLines.add(layoutLine2)
        layoutLines.add(layoutLine3)
        layoutLines.add(layoutLine4)

        myKeysText.clear()
        myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardTypeSetup.get())

        setLayoutComponents()

    }

    //

    // 屏幕韩文软键盘模式切换
    @SuppressLint("ResourceAsColor")
    private fun setLayoutComponents() {
        var myOnClickListener: View.OnClickListener? = null
        for (line in layoutLines.indices) {
            val children = layoutLines[line].children.toList()
            val myText = myKeysText[line]
//            Log.i("CAI", "Layoutline:"+children.toString())
            //var longClickIndex = 0
            for (item in children.indices) {
                val actionButton = children[item].findViewById<Button>(R.id.key_button)
                val spacialKey = children[item].findViewById<ImageView>(R.id.spacial_key)

                when (myText[item]) {

                    "SPACE" -> {
                        spacialKey.setImageResource(R.drawable.ic_space)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        actionButton.text = "조선어"
                        myOnClickListener = getSpaceAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        spaceButton = actionButton
                    }
                    "DEL" -> {
                        spacialKey.setImageResource(R.drawable.ic_backspace)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getDeleteAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        delButton = actionButton
                    }
                    "ABC" -> {
                        isCaps = false
                        spacialKey.setImageResource(R.drawable.ic_abc)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getEngAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        Log.i("CAI","setLayoutComponents-engABC---")
                        langButton = actionButton
                    }
                    "CAPS" -> {
                        isCaps = false
                        spacialKey.setImageResource(R.drawable.ic_abc)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        capsView = spacialKey
                        myOnClickListener = getCapsAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        Log.i("CAI","setLayoutComponents-engCAPS---")
                        capsButton = actionButton
                    }
                    "ㄱㄴㄷ" -> {
                        isCaps = false
                        spacialKey.setImageResource(R.drawable.ic_gnd)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getKorAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        Log.i("CAI","setLayoutComponents-engGND---")
                        //langButton = actionButton
                    }
                    "!@#" -> {
                        isCaps = false
                        spacialKey.setImageResource(R.drawable.ic_sym)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getSymAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        Log.i("CAI","setLayoutComponents-eng！@#---")
                        //capsButton = actionButton
                    }
                    "123" -> {
                        isCaps = false
                        spacialKey.setImageResource(R.drawable.ic_num)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getNumAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        Log.i("CAI","setLayoutComponents-eng123---")
                        //capsButton = actionButton
                    }

                    "ENTER" -> {
                        spacialKey.setImageResource(R.drawable.ic_return)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = getEnterAction()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                        enterButton = actionButton
                    }

                    "▼" -> {
                        actionButton.text = "▼"
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_black)
                        buttons.add(actionButton)
                        myOnClickListener = hideKeyboard()
                        actionButton.setOnClickListener(myOnClickListener)
                    }
                    "☯" -> {
                        spacialKey.setImageResource(R.drawable.ic_kor)
                        spacialKey.visibility = View.VISIBLE
                        actionButton.visibility = View.GONE
                        myOnClickListener = selectKeyboard()
                        spacialKey.setOnClickListener(myOnClickListener)
                        spacialKey.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        spacialKey.setBackgroundResource(R.drawable.keyboard_key_black)
                    }

                    "   " -> {
                        actionButton.text = "   "
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_black)
                    }

                    "y","Y" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]

                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        //actionButton.setTextColor(R.color.white)
                        buttons.add(actionButton)
                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        yButton = actionButton
//                        Log.i("CAI", "ybutton:"+ yButton.toString())
                    }
                    "i","I" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]

                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        //actionButton.setTextColor(R.color.white)
                        buttons.add(actionButton)

                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        iButton = actionButton
                    }
                    "a","A" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]
                        //actionButton.setTextColor(R.color.white)
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        buttons.add(actionButton)

                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        aButton = actionButton
                    }
                    "e","E" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]
                        //actionButton.setTextColor(R.color.white)
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        buttons.add(actionButton)
                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        eButton = actionButton
                    }
                    "o","O" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]
                        // actionButton.setTextColor(R.color.white)
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        buttons.add(actionButton)
                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        oButton = actionButton
                    }
                    "u","U" ->{
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]
                        // actionButton.setTextColor(R.color.white)
                        actionButton.setBackgroundResource(R.drawable.keyboard_key_red)
                        buttons.add(actionButton)
                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
                        uButton = actionButton
                    }
                    else -> {
                        actionButton.text = myText[item]
                        actionButton.tag = myText[item]

                        actionButton.setBackgroundResource(R.drawable.keyboard_key_blue)
                        //actionButton.setTextColor(R.color.white)
                        buttons.add(actionButton)

                        myOnClickListener = getEngClickListener(actionButton)
                        actionButton.setOnTouchListener(getOnTouchListener(myOnClickListener))
//                                  Log.i("CAI", "FnnQrtt-kor->else ${actionButton.text}")
                    }
                }
                children[item].setOnClickListener(myOnClickListener)
            }
        }
        //     Log.i("CAI", "视图-QfKbvHanyin")

    }

    //

    private fun getEngClickListener(actionButton: Button): View.OnClickListener {
        val clickListener = (View.OnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                inputConnection?.requestCursorUpdates(InputConnection.CURSOR_UPDATE_IMMEDIATE)
            }
            playVibrate()
            val cursorcs: CharSequence? = inputConnection?.getSelectedText(InputConnection.GET_TEXT_WITH_STYLES)
            if (cursorcs != null && cursorcs.length >= 2) {

                val eventTime = SystemClock.uptimeMillis()
                inputConnection?.finishComposingText()
                inputConnection?.sendKeyEvent(KeyEvent(eventTime, eventTime,
                    KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD))
                inputConnection?.sendKeyEvent(KeyEvent(SystemClock.uptimeMillis(), eventTime,
                    KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD))
                inputConnection?.sendKeyEvent(KeyEvent(eventTime, eventTime,
                    KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD))
                inputConnection?.sendKeyEvent(KeyEvent(SystemClock.uptimeMillis(), eventTime,
                    KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_LEFT, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD))

            } else {
                when (actionButton.text.toString()) {
                    "☯" -> {
                        //                    Log.i("CAI", "qfkbvEnglish->else ${actionButton.text} ,${Setup.getKeyboardType()}")
//                        Setup.setKeyboardType(Setup.KeyboardType.KbQfHanyin)
                        KeyboardTypeSetup.set(KeyboardType.FnnQtryKor)
                        keyboardInterationListener.changeMode(KeyboardType.FnnQtryKor)
                        //getKbdAction()
                    }
                    else -> {
                        playClick(
                            actionButton.text.toString().toCharArray().get(
                                0
                            ).code
                        )
                        inputConnection?.commitText(actionButton.text, 1)
                    }
                }
            }
        })
        actionButton.setOnClickListener(clickListener)
        return clickListener
    }


    //
    fun getSpaceAction(): View.OnClickListener {
        return View.OnClickListener {
            //resetMolym()
            //
            playClick('ㅁ'.code)
            playVibrate()
            hanyinCode.commitSpace()
        }
    }
    //

    fun getDeleteAction(): View.OnClickListener {
        return View.OnClickListener {
            //resetMolym()
            //
            playVibrate()
            val cursorcs: CharSequence? = inputConnection?.getSelectedText(InputConnection.GET_TEXT_WITH_STYLES)
            if (cursorcs != null && cursorcs.length >= 2) {

                val eventTime = SystemClock.uptimeMillis()
                inputConnection?.finishComposingText()
                inputConnection?.sendKeyEvent(
                    KeyEvent(
                        eventTime, eventTime,
                        KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                        KeyEvent.FLAG_SOFT_KEYBOARD
                    )
                )
                inputConnection?.sendKeyEvent(
                    KeyEvent(
                        SystemClock.uptimeMillis(), eventTime,
                        KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                        KeyEvent.FLAG_SOFT_KEYBOARD
                    )
                )
                hanyinCode.clear()
            } else {
                hanyinCode.delete()
            }
        }
    }
    //
    fun getEngAction(): View.OnClickListener {
        return View.OnClickListener {
            playVibrate()
            hanyinCode.commitChange()
            KeyboardTypeSetup.set(KeyboardType.FnnQtryEng)
            Log.i("CAI", "fnn-eng:")
            keyboardInterationListener.changeMode(KeyboardTypeSetup.get())

        }
    }
    //
    fun getCapsAction(): View.OnClickListener {
        return View.OnClickListener {
            isCaps = !isCaps
            Log.i("CAI", "getCapsActin---")
            playVibrate()
            capsChangeMode()

        }
    }
    //
    fun capsChangeMode() {
        if (isCaps) {
            capsButton.text = "CAPS"
            capsView?.setImageResource(R.drawable.ic_fnn)
            //capsView?.visibility = View.VISIBLE
            //capsView?.visibility = View.GONE
            for (button in buttons) {
                if(button.text.length == 1 ) {
                    button.text = button.text.toString().uppercase(Locale.getDefault())
                    //Log.i("CAI", "isCaps:" + button.text.toString())
                }
            }
        } else {
            capsButton.text = "CAPS"
            capsView?.setImageResource(R.drawable.ic_abc)
            //capsView?.visibility = View.VISIBLE
            //capsView?.visibility = View.GONE
            for (button in buttons) {
                if(button.text.length == 1) {
                    button.text = button.text.toString().lowercase(Locale.getDefault())
                    //Log.i("CAI", "noCaps:" + button.text.toString())
                }
            }

        }
    }
    //
    fun getKorAction(): View.OnClickListener {
        return View.OnClickListener {
            playVibrate()
            hanyinCode.commitChange()
            KeyboardTypeSetup.set(KeyboardType.FnnQtryKor)
            Log.i("CAI", "fnn-kor:")
            keyboardInterationListener.changeMode(KeyboardTypeSetup.get())
            //capsButton.text = "123"
            //langButton.text = "ABC"

        }
    }
    //
    fun getSymAction(): View.OnClickListener {
        return View.OnClickListener {
            playVibrate()
            hanyinCode.commitChange()
            KeyboardTypeSetup.set(KeyboardType.FnnQrtySym)
            Log.i("CAI", "fnn-sym:")
            keyboardInterationListener.changeMode(KeyboardTypeSetup.get())
            //capsButton.text = "123"
            //capsButton.text = "123"
            //langButton.text = "ㄱㄴㄷ"

        }
    }
    //
    fun getNumAction(): View.OnClickListener {
        return View.OnClickListener {
            playVibrate()
            hanyinCode.commitChange()
            KeyboardTypeSetup.set(KeyboardType.FnnQtryNum)
            Log.i("CAI", "fnn-num:")
            keyboardInterationListener.changeMode(KeyboardTypeSetup.get())
            //capsButton.text = "!@#"
            //langButton.text = "ㄱㄴㄷ"

        }
    }
    //
    fun getEnterAction(): View.OnClickListener {
        return View.OnClickListener {
            playVibrate()
            hanyinCode.directlyCommit()
            val eventTime = SystemClock.uptimeMillis()
            inputConnection?.sendKeyEvent(
                KeyEvent(
                    eventTime, eventTime,
                    KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD
                )
            )
            inputConnection?.sendKeyEvent(
                KeyEvent(
                    SystemClock.uptimeMillis(), eventTime,
                    KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0, 0, 0, 0,
                    KeyEvent.FLAG_SOFT_KEYBOARD
                )
            )
        }
    }
    //
    fun hideKeyboard(): View.OnClickListener {
        return View.OnClickListener {

            val imm: InputMethodManager? = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            if (imm != null) {
                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }
    //
    fun selectKeyboard(): View.OnClickListener {
        return View.OnClickListener {

            val imm: InputMethodManager? = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            if (imm != null) {
                imm.showInputMethodPicker()
            }
        }
    }
    //

    private fun getKorClickListener(actionButton: Button): View.OnClickListener {

        val clickListener = (View.OnClickListener {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                inputConnection?.requestCursorUpdates(InputConnection.CURSOR_UPDATE_IMMEDIATE)
            }
            playVibrate()
            val cursorcs: CharSequence? = inputConnection?.getSelectedText(InputConnection.GET_TEXT_WITH_STYLES)
            if (cursorcs != null && cursorcs.length >= 2) {

                val eventTime = SystemClock.uptimeMillis()
                inputConnection?.finishComposingText()
                inputConnection?.sendKeyEvent(
                    KeyEvent(
                        eventTime, eventTime,
                        KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                        KeyEvent.FLAG_SOFT_KEYBOARD
                    )
                )
                inputConnection?.sendKeyEvent(
                    KeyEvent(
                        SystemClock.uptimeMillis(), eventTime,
                        KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL, 0, 0, 0, 0,
                        KeyEvent.FLAG_SOFT_KEYBOARD
                    )
                )
                hanyinCode.clear()
            }
            //
            when (actionButton.text.toString()) {

                else -> {


                    playClick(actionButton.text.toString().toCharArray().get(0).code)
//                    Log.i("CAI", "FnnQtry-playClick:"+actionButton.text.toString().toCharArray().get(0).toString())
                    try {
                        val mText = Integer.parseInt(actionButton.text.toString())

//                        Log.i("CAI", "FnnQtry-try{}: "+ actionButton.text.toString())
                        hanyinCode.directlyCommit()
                        inputConnection?.commitText(actionButton.text.toString(), 1)

                    } catch (e: NumberFormatException) {
                        hanyinCode.commit(actionButton.text.toString().toCharArray().get(0))
//                        Log.i("CAI", "FnnQrty-try catch (e: NumberFormatException):"+actionButton.text.toString().toCharArray().get(0))

                    }

//                    if (isCaps) {
//                        modeChange()
//                    }
                    ////////////////////////////
                    when (actionButton.text.toString()) {
                        "ㅡ" -> {
                            setMolym("ㅡ")
                            //Log.i("CAI", "when:"+"ㅡ")
                        }
                        "ㅣ" -> {
                            setMolym("ㅣ")
                            //Log.i("CAI", "when:"+"ㅣ")
                        }
                        "ㅗ" -> {
                            setMolym("ㅗ")
                            //Log.i("CAI", "when:"+"ㅗ")
                        }
                        "ㅏ" -> {
                            setMolym("ㅏ")
                            //Log.i("CAI", "when:"+"ㅏ")
                        }
                        "ㅓ" -> {
                            setMolym("ㅓ")
                            //Log.i("CAI", "when:"+"ㅓ")
                        }
                        "ㅜ" -> {
                            setMolym("ㅜ")
                            //Log.i("CAI", "when:"+"ㅜ")
                        }
                        "ㅝ" -> {
                            setMolym("ㅝ")
                            //Log.i("CAI", "when:"+"ㅝ")
                        }
                        "ㅘ" -> {
                            setMolym("ㅘ")
                            //Log.i("CAI", "when:"+"ㅘ")
                        }
                        "ㅔ" -> {
                            setMolym("ㅔ")
                            //Log.i("CAI", "when:"+"ㅔ")
                        }
                        "ㅐ" -> {
                            setMolym("ㅐ")
                            //Log.i("CAI", "when:"+"ㅐ")
                        }
                        "ㅕ" -> {
                            setMolym("ㅕ")
                            //Log.i("CAI", "when:"+"ㅕ")
                            //   resetMolym()
                        }
                        "ㅑ" -> {
                            setMolym("ㅑ")
                            //Log.i("CAI", "when:"+"ㅑ")
                            //   resetMolym()
                        }
                        "ㅛ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅛ")
                            //   resetMolym()
                        }
                        "ㅠ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅠ")
                            //   resetMolym()
                        }
                        "ㅟ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅟ")
                            //   resetMolym()
                        }
                        "ㅚ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅚ")
                            //   resetMolym()
                        }
                        "ㅢ" -> {
                            resetMolym()
//                            Log.i("CAI", "when:"+"ㅢ")
                            //   resetMolym()
                        }
                        "ㅙ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅙ")
                            //   resetMolym()
                        }
                        "ㅞ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅞ")
                            //   resetMolym()
                        }

                        "ㅖ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅖ")
                            //   resetMolym()
                        }
                        "ㅒ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅒ")
                            //   resetMolym()
                        }

                        "ㄲ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄲ")
                        }
                        "ㄱ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄱ")
                        }
                        "ㅋ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅋ")
                        }
                        "ㅥ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅥ")
                        }
                        "ㄴ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄴ")
                        }
                        "ㄹ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄹ")
                        }
                        "ㄸ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄸ")
                        }
                        "ㄷ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㄷ")
                        }
                        "ㅌ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅌ")
                        }
                        "ㅁ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅁ")
                        }
                        "ㅇ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅇ")
                        }
                        "ㅃ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅃ")
                        }
                        "ㅂ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅂ")
                        }
                        "ㅍ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅍ")
                        }
                        "ㅆ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅆ")
                        }
                        "ㅅ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅅ")
                        }
                        "ㅎ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅎ")
                        }
                        "ㅉ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅉ")
                        }
                        "ㅈ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅈ")
                        }
                        "ㅊ" -> {
                            resetMolym()
                            //Log.i("CAI", "when:"+"ㅊ")
                        }
//                        "space" -> {
//                            resetMolym()
//                            Log.i("CAI", "when:"+"space")
//                        }
//                        "DEL" -> {
//                            resetMolym()
//                            Log.i("CAI", "when:"+"DEL")
//                        }
                    }
                    ////////////////////////////

                }

            }

        })

        actionButton.setOnClickListener(clickListener)
        return clickListener
    }



    ///////////////////////
    //
    private fun playClick(i: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager?
        when (i) {
            32 -> am!!.playSoundEffect(AudioManager.FX_KEYPRESS_SPACEBAR)
            Keyboard.KEYCODE_DONE, 10 -> am!!.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN)
            Keyboard.KEYCODE_DELETE -> am!!.playSoundEffect(AudioManager.FX_KEYPRESS_DELETE)
            else -> am!!.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1.toFloat())
        }
    }
    //
    private fun playVibrate() {
        if (vibrate > 0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(70, vibrate))
            } else {
                vibrator.vibrate(70)
            }
        }
    }
    //
    fun resetMolym(){
        yButton.text = "ㅡ"
        iButton.text = "ㅣ"
        aButton.text = "ㅏ"
        eButton.text = "ㅓ"
        oButton.text = "ㅗ"
        uButton.text = "ㅜ"
    }
    //
    // 当 u,e,a,o 时 y变 yu,ye,ya,yo; i 变为 iu,ie,ia,io
    // 设置元音的组合方式
    fun setMolym(ch : String) {
        when (ch) {
            "ㅏ" -> {
                yButton.text = "ㅑ"
                iButton.text = "ㅐ"
                //
                eButton.text = "ㅓ"
                uButton.text = "ㅜ"
            }
            "ㅓ" -> {
                yButton.text = "ㅕ"
                iButton.text = "ㅔ"
                //
                aButton.text = "ㅏ"
                oButton.text = "ㅗ"
            }
            "ㅗ" -> {
                yButton.text = "ㅛ"
                iButton.text = "ㅚ"
                aButton.text = "ㅘ"
                //
                eButton.text = "ㅓ"
                uButton.text = "ㅜ"
            }
            "ㅜ" -> {
                yButton.text = "ㅠ"
                iButton.text = "ㅟ"
                eButton.text = "ㅝ"
                //
                aButton.text = "ㅏ"
                oButton.text = "ㅗ"
            }
            "ㅡ" -> {
                iButton.text = "ㅢ"
                //
                aButton.text = "ㅑ"
                oButton.text = "ㅛ"
                eButton.text = "ㅕ"
                uButton.text = "ㅠ"
            }
            "ㅣ" -> {
                yButton.text = "ㅢ"
                //
                aButton.text = "ㅐ"
                oButton.text = "ㅚ"
                eButton.text = "ㅔ"
                uButton.text = "ㅟ"
            }
            "ㅕ" -> {
                iButton.text = "ㅖ"
            }
            "ㅔ" -> {
                yButton.text = "ㅖ"
            }
            "ㅑ" -> {
                iButton.text = "ㅒ"
            }
            "ㅐ" -> {
                yButton.text = "ㅒ"
            }
            "ㅝ" -> {
                iButton.text = "ㅞ"
                yButton.text = "ㅡ"
            }
            "ㅘ" -> {
                iButton.text = "ㅙ"
                yButton.text = "ㅡ"
            }
        }
    }

    //
    fun getOnTouchListener(clickListener: View.OnClickListener): View.OnTouchListener {
        val handler = Handler()
        val initailInterval = 500
        val normalInterval = 100
        val handlerRunnable = object : Runnable {
            override fun run() {
                handler.postDelayed(this, normalInterval.toLong())
                clickListener.onClick(downView)
            }
        }
        val onTouchListener = object : View.OnTouchListener {
            override fun onTouch(view: View?, motionEvent: MotionEvent?): Boolean {
                when (motionEvent?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        handler.removeCallbacks(handlerRunnable)
                        handler.postDelayed(handlerRunnable, initailInterval.toLong())
                        downView = view!!
                        clickListener.onClick(view)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(handlerRunnable)
                        downView = null
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(handlerRunnable)
                        downView = null
                        return true
                    }
                }
                return false
            }
        }
//        Log.i("CAI","getOnTouchListener: "+downView.toString())
        return onTouchListener
    }

    //
    //
    fun getLayout(mode: KeyboardType): LinearLayout {
        when(mode) {
            KeyboardType.FnnQtryKor -> {
                hanyinCode = FnnHanyinCode(inputConnection!!)
                //myKeysText.clear()
                myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardType.FnnQtryKor)
                Log.i("CAI", "getLayout-Kor:"+myKeysText.toString())

                setLayoutComponents()
            }
            KeyboardType.FnnQtryEng -> {
                hanyinCode = FnnHanyinCode(inputConnection!!)
                //myKeysText.clear()
                myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardType.FnnQtryEng)
                Log.i("CAI", "getLayout-Eng:"+myKeysText.toString())
                // setLayoutComponentsEx()
                setLayoutComponents()
            }
            KeyboardType.FnnQtryNum -> {
                hanyinCode = FnnHanyinCode(inputConnection!!)
                //myKeysText.clear()
                myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardType.FnnQtryNum)
                Log.i("CAI", "getLayout-Num:"+myKeysText.toString())
                // setLayoutComponentsEx()
                setLayoutComponents()
            }
            KeyboardType.FnnQrtySym -> {
                hanyinCode = FnnHanyinCode(inputConnection!!)
                //myKeysText.clear()
                myKeysText = KeyboardTypeKeys.get10Keyboard(KeyboardType.FnnQrtySym)
                Log.i("CAI", "getLayout-sym:"+myKeysText.toString())
                //setLayoutComponentsEx()
                setLayoutComponents()
            }
        }

        return keyboardLayout
    }

    ///
}