package com.caixnet.fnnqrtyime

import com.caixnet.fnnqrtyime.config.KeyboardType


interface KeyboardInterationListener {
   // fun modeChange(mode: KeyboardType)
    fun changeMode(mode: KeyboardType)
}