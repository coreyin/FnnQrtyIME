package com.caixnet.fnnqrtyime.code

import android.util.Log
import android.view.inputmethod.InputConnection


open class FnnHanyinCode {

    private var isHanyin: Boolean = false
    private var isDxCode: Boolean = true

    // private val "CAI" = "HanyinMaker"
    // coSel: 初声
    private var coSel: Char = '\u0000'
    private var coSelIndex: Int = 0

    // zulSel: 中声
    private var zulSel: Char = '\u0000'
    private var zulSelIndex: Int = 0

    // zolSel: 终声
    private var zolSel: Char = '\u0000'
    private var zolSelIndex: Int = 0

    private var zolSelFlag: Char = '\u0000'
    private var doublezolSelFlag: Char = '\u0000'
    var zulSelFlag: Char = '\u0000'

    /*
    변수로 사용할 초성(coSel), 중성(zulSel), 종성(zolSel)과
    초성, 중성, 종성에 입력 가능한 유니코드를 리스트로 선언.
     Flag는 이중모음, 이중자음을 처리하기 위한 변수.
    * */

    /*
    定义组合字母的初声、中声和终声
     */

    /* U+3165, &#12645; Unicode0x3165(ㅥ)是朝鮮語的古老字符之一跟F平躺相似，韩语里没有英文和中文中的F的F音 */

    /* ㄱ ㄲ ㄴ ㄷ ㄸ ㄹ ㅁ ㅂ ㅃ ㅅ ㅆ ㅇ ㅈ ㅉ ㅊ ㅋ ㅌ ㅍ ㅎ ㅥ */
    private val coSels: List<Int> = listOf(0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139, 0x3141,
        0x3142, 0x3143, 0x3145, 0x3146, 0x3147, 0x3148, 0x3149, 0x314a, 0x314b, 0x314c, 0x314d,
        0x314e, 0x3165 /* 0x3165=ㅥ 쌍니은 F */)

    /* ㅏ ㅐ ㅑ ㅒ ㅓ ㅔ ㅕ ㅖ ㅗ ㅘ ㅙ ㅚ ㅛ ㅜ ㅝ ㅞ ㅟ ㅠ ㅡ ㅢ ㅣ */
    private val zulSels: List<Int> = listOf(0x314f, 0x3150, 0x3151, 0x3152, 0x3153, 0x3154, 0x3155,
        0x3156, 0x3157, 0x3158, 0x3159, 0x315a, 0x315b, 0x315c, 0x315d, 0x315e, 0x315f, 0x3160,
        0x3161, 0x3162, 0x3163)

    /* ㄱ ㄲ ㄳ ㄴ ㄵ ㄶ ㄷ ㄹ ㄺ ㄻ ㄼ ㄽ ㄾ ㄿ ㅀ ㅁ ㅂ ㅄ ㅅ ㅆ ㅇ ㅈ ㅊ ㅋ ㅌ ㅍ ㅎ */
    private val zolSels: List<Int> = listOf(0x0000, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136,
        0x3137, 0x3139, 0x313a, 0x313b, 0x313c, 0x313d, 0x313e, 0x313f, 0x3140, 0x3141, 0x3142,
        0x3144, 0x3145, 0x3146, 0x3147, 0x3148, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e)

    /**
     * 0:""
     * 1: 모음 입력상태
     * 2: 모음 + 자음 입력상태
     * 3: 모음 + 자음 + 모음입력상태(초 중 종성)
     * 초성과 종성에 들어갈 수 있는 문자가 다르기 때문에 필요에 맞게 수정이 필요함.(coSels != zolSels)
     */
    protected var state = 0
    private var inputConnection: InputConnection

    constructor(inputConnection: InputConnection) {
        this.inputConnection = inputConnection

    }

    // 情况状态
    fun clear() {
        coSel = '\u0000'
        zulSel = '\u0000'
        zolSel = '\u0000'
        //
        zulSelFlag = '\u0000'
        zolSelFlag = '\u0000'
        doublezolSelFlag = '\u0000'

    }

    //计算出韩文字符编码
    fun makeHanyin(): Char {
        if (state == 0) {
            return '\u0000'
        }
        if (state == 1) {
            return coSel
        }

        coSelIndex = coSels.indexOf(coSel.code)

        zulSelIndex = zulSels.indexOf(zulSel.code)
        zolSelIndex = zolSels.indexOf(zolSel.code)

        val makeResult = codeHanyin(coSelIndex, zulSelIndex, zolSelIndex)
        Log.i("CAI", " ****makeHanyin():" + coSelIndex + "," + zulSelIndex + "," + zolSelIndex + ":" + makeResult.toChar())
        return makeResult.toChar()
    }

    /*
    fa	0xd7a4	0xe100
    fe	0xd7a5	0xe170
    fo	0xd7a6	0xe1e0
    fu	0xd7a7	0xe26c
    fy	0xd7a8	0xe2f8
    fi	0xd7a9	0xe330
    fan	0xd7aa	0xe104
    fal	0xd7ab	0xe115
    fen	0xd7ac	0xe174
    fel	0xd7ad	0xe185
    feh	0xd7ae	0xe18b
    fieh 0xd7af	0xe1a7

     */
    fun ex2dxcode(fnn: Int): Int {
        var fnncode:Int = 0
        when (fnn){
            0xe100 -> fnncode = 0xd7a4  // fa
            0xe170 -> fnncode = 0xd7a5  // fe
            0xe1e0 -> fnncode = 0xd7a6  // fo
            0xe26c -> fnncode = 0xd7a7  // fu
            0xe2f8 -> fnncode = 0xd7a8  // fy
            0xe330 -> fnncode = 0xd7a9  // fi
            0xe104 -> fnncode = 0xd7aa  // fan
            0xe115 -> fnncode = 0xd7ab  // fal
            0xe174 -> fnncode = 0xd7ac  // fen
            0xe185 -> fnncode = 0xd7ad  // fel
            0xe18b -> fnncode = 0xd7ae  // feh
            0xe1a7 -> fnncode = 0xd7af  // fieh
            else -> fnncode = fnn
        }
        Log.i("CAI", "ex2dxcode: "+ Integer.toHexString(fnncode))
        return fnncode
    }
    // 言文韩语编码，
    fun codeHanyin(coSelIndex: Int, zulSelIndex: Int, zolSelIndex: Int): Int {
        var fnncode:Int
        // 当输入键值索引为19，及键值为 0x3165=ㅥ 쌍니은 F时 处理
        if (coSelIndex == 19) {
            fnncode = 0xE100 + 28 * (zulSelIndex) + zolSelIndex
            if (isDxCode) {
                fnncode = ex2dxcode(fnncode)
                Log.i("CAI", "ex2d: "+ Integer.toHexString(fnncode))
            }
        } else {
            fnncode = 0xAC00 + 28 * 21 * (coSelIndex) + 28 * (zulSelIndex) + zolSelIndex
        }
        Log.i("CAI", "codeHanyin: "+ Integer.toHexString(fnncode))
        return fnncode
    }

    // 言文韩语解码，
    fun decodeHanyin(code: Int, idx: Int = 2): Int {
        var mCode: Int = 0
        var mCoSel: Int = 0
        var mZulSel: Int = 0
        var mZolSel: Int = 0
        if (code >= 0xE100 && code <= 0xE34B) {
            mCode = code - 0xE100
//            mCoSel = 'ㅥ'.toInt()
            mCoSel = 19
            mZulSel = mCode / 28
            mZolSel = mCode % 28
        } else if (code >= 0xAC00 && code <= 0xD7FF) {
            mCode = code - 0xAC00
            mCoSel = mCode / (28 * 21)
            mZulSel = (mCode % (28 * 21)) / 28
            mZolSel = (mCode % (28 * 21)) % 28
        }
        when (idx) {
            1 -> mCode = mCoSel
            2 -> mCode = mZulSel
            3 -> mCode = mZolSel
        }
        //Log.i("CAI","----${mCoSel}: ${coSels[mCoSel].toChar()}, ${mZulSel}:${zulSels[mZulSel].toChar()},${mZolSel}:${zolSels[mZolSel].toChar()}")

        return mCode
    }

    /*
    * 우선 첫번째 상태는 아무것도 입력되지 않은 상태로 모음 또는 자음을 기대할 수 있습니다.
    * 여기서 자음이 입력된다면 B의 상태로, 모음이 입력된다면 E의 상태로 이동합니다.
    *  B의 상태에서는 다시 한번 자음을 입력하거나, 모음을 입력할 수 있습니다.
    * 만약 자음을 입력한다면 이전 문자를 commit하고 다음 문자로 텍스트를 구성할 수 있습니다(상태는 고정).
    * 그리고 모음이 들어온다면 3번예시와 같은 자음+모음의 C상태로 이동합니다.
    * 마지막으로 C상태에서 자음이 들어온다면 자음+모음+자음 조합의 한 글자가 완성될 수 있고(상태 D),
    *  모음이 들어온다면 이전에 완성된 문자를 commit하고 모음만으로 구성된 E의 상태가 됩니다.
    * 여기까지가 우리가 일반적으로 사용하는 A-B-C-D의 상태변화이고 그림에는 예외상황을 포함한 글자 예시가 들어있습니다.
    * */

    // 判断和处理组合字符
    open fun commit(c: Char) {
        if (coSels.indexOf(c.code) < 0 && zulSels.indexOf(c.code) < 0 && zolSels.indexOf(c.code) < 0) {
            directlyCommit()
            inputConnection.commitText(c.toString(), 1)
//            Log.i("CAI", " if -> commit():" + c.toString())
            return
        }
        //判断输入字符组合成字
        when (state) {
            0 -> {
                if (zulSels.indexOf(c.code) >= 0) {
                    inputConnection.commitText(c.toString(), 1)
//                    Log.i("CAI", " commit(0):" + c.toString())
                    clear()
                } else {//초성일 경우
                    state = 1
                    coSel = c
                    inputConnection.setComposingText(coSel.toString(), 1)
//                    Log.i("CAI", " commit(!0):" + c.toString())
                }
            }
            1 -> {
                if (coSels.indexOf(c.code) >= 0) {
                    inputConnection.commitText(coSel.toString(), 1)
                    clear()
                    coSel = c
                    inputConnection.setComposingText(coSel.toString(), 1)
//                    Log.i("CAI", " commit(1):" + c.toString())
                } else {//중성일 경우
                    state = 2
                    zulSel = c
                    inputConnection.setComposingText(makeHanyin().toString(), 1)
//                    Log.i("CAI", " commit(M!1):" + c.toString())
                }
            }
            2 -> {
                if (zulSels.indexOf(c.code) >= 0) {
                    if (doubleZulSelEnable(c)) {
                        inputConnection.setComposingText(makeHanyin().toString(), 1)
//                        Log.i("CAI", " commit(M2-zulSel):" + c.toString())
                    } else {

                        inputConnection.commitText(makeHanyin().toString(), 1)
                        //var preChar = makeHanyin()

                        /* ㅏ ㅐ ㅑ ㅒ ㅓ ㅔ ㅕ ㅖ ㅗ ㅘ ㅙ ㅚ ㅛ ㅜ ㅝ ㅞ ㅟ ㅠ ㅡ ㅢ ㅣ */
                        // 27= ㅎ
                        //var aaa = codeHanyin(decodeHanyin(preChar.toInt(), 1), decodeHanyin(preChar.toInt(), 2), 27)
                        //inputConnection.commitText(preChar.toString(), 1)

                        inputConnection.commitText(c.toString(), 1)
                        clear()
                        state = 0

//
                    }
                } else if (zolSels.indexOf(c.code) >= 0) {//종성이 들어왔을 경우
                    zolSel = c
                    inputConnection.setComposingText(makeHanyin().toString(), 1)
                    state = 3
//                    Log.i("CAI", " commit(M!2-zolSel):" + c.toString())
                } else {
                    directlyCommit()
                    coSel = c
                    state = 1
                    inputConnection.setComposingText(makeHanyin().toString(), 1)
//                    Log.i("CAI", " commit(M!2):" + c.toString())
                }
            }
            3 -> {
                if (zolSels.indexOf(c.code) >= 0) {
                    if (doublezolSelEnable(c)) {
                        inputConnection.setComposingText(makeHanyin().toString(), 1)
//                        Log.i("CAI", " commit(M3+zolSel):" + c.toString())
                    } else {
                        inputConnection.commitText(makeHanyin().toString(), 1)
                        clear()
                        state = 1
                        coSel = c
                        inputConnection.setComposingText(coSel.toString(), 1)
//                        Log.i("CAI", " commit(M3+!zolSel):" + c.toString())
                    }

                } else if (coSels.indexOf(c.code) >= 0) {
                    inputConnection.commitText(makeHanyin().toString(), 1)
                    state = 1
                    clear()
                    coSel = c
                    inputConnection.setComposingText(coSel.toString(), 1)
//                    Log.i("CAI", " commit(M3+!):" + c.toString())
                } else {//중성이 들어올 경우
                    var temp: Char
                    if (doublezolSelFlag == '\u0000') {
                        temp = zolSel
                        zolSel = '\u0000'
                        inputConnection.commitText(makeHanyin().toString(), 1)
                        //              Log.i("CAI", " commit(M4+zolSel):" + c.toString())
                    } else {
                        temp = doublezolSelFlag
                        zolSel = zolSelFlag
                        inputConnection.commitText(makeHanyin().toString(), 1)
                        //              Log.i("CAI", " commit(M4+!zolSel):" + c.toString())
                    }
                    state = 2
                    clear()
                    coSel = temp
                    zulSel = c
                    inputConnection.setComposingText(makeHanyin().toString(), 1)
//                    Log.i("CAI", " commit(M5+):" + c.toString())
                }
            }

        }
        //Log.i("CAI", " after -> when: commit():" + c.toString())
    }

    // 递交空格
    open fun commitSpace() {
        directlyCommit()
        inputConnection.commitText(" ", 1)
    }
    // 递交空格
    open fun commitChange() {
        directlyCommit()
//        Log.i("CAI", " ****makeHanyin():" + coSelIndex + "," + zulSelIndex + "," + zolSelIndex )
    }

    //直接提交
    open fun directlyCommit() {
        if (state == 0) {
            Log.i("CAI", " fnnHanyinCode.kt-directlyCommit(0):" + makeHanyin().toString())
            return
        }
        inputConnection.commitText(makeHanyin().toString(), 1)
        Log.i("CAI", "fnnHanyinCode.kt- directlyCommit(1):" + makeHanyin().toString())
        state = 0
        clear()
    }

    // 删除回滚
    open fun delete() {
        when (state) {
            0 -> {
                inputConnection.deleteSurroundingText(1, 0)
            }
            1 -> {
                coSel = '\u0000'
                state = 0
                inputConnection.setComposingText("", 1)
                inputConnection.commitText("", 1)
            }
            2 -> {
                if (zulSelFlag != '\u0000') {
                    zulSel = zulSelFlag
                    zulSelFlag = '\u0000'
                    state = 2
                    inputConnection.setComposingText(makeHanyin().toString(), 1)
                } else {
                    zulSel = '\u0000'
                    zulSelFlag = '\u0000'
                    state = 1
                    inputConnection.setComposingText(coSel.toString(), 1)
                }
            }
            3 -> {
                if (doublezolSelFlag == '\u0000') {
                    zolSel = '\u0000'
                    state = 2
                } else {
                    zolSel = zolSelFlag
                    zolSelFlag = '\u0000'
                    doublezolSelFlag = '\u0000'
                    state = 3
                }
                inputConnection.setComposingText(makeHanyin().toString(), 1)
            }
        }
    }

    // 复合元音
    fun doubleZulSelEnable(c: Char): Boolean {
//        Log.i("CAI", "doublezulSelEnbable:" + zulSel +","+c.toString())
        when (zulSel) {

            'ㅡ' -> {
                if (c == 'ㅢ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅢ'
                    return true
                } else if (c == 'ㅑ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅑ'
                    return true
                } else if (c == 'ㅕ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅕ'
                    return true
                } else if (c == 'ㅛ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅛ'
                    return true
                } else if (c == 'ㅠ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅠ'
                    return true
                }

                return false
            }

            'ㅣ' -> {
                if (c == 'ㅢ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅢ'
                    return true
                } else if (c == 'ㅐ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅐ'
                    return true
                } else if (c == 'ㅔ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅔ'
                    return true
                } else if (c == 'ㅚ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅚ'
                    return true
                } else if (c == 'ㅟ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅟ'
                    return true
                }

                return false
            }

            'ㅏ' -> {
                if (c == 'ㅑ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅑ'
                    return true
                } else if (c == 'ㅐ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅐ'
                    return true
                }

                return false
            }
            'ㅑ' -> {
                if (c == 'ㅒ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅒ'
                    return true
                }
                return false
            }

            'ㅐ' -> {
                if (c == 'ㅒ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅒ'
                    return true
                }
                return false
            }

            'ㅓ' -> {
                if (c == 'ㅕ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅕ'
                    return true
                } else if (c == 'ㅔ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅔ'
                    return true
                }

                return false
            }
            'ㅔ' -> {
                if (c == 'ㅖ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅖ'
                    return true
                }
                return false
            }
            'ㅕ' -> {
                if (c == 'ㅖ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅖ'
                    return true
                }
                return false
            }

            'ㅗ' -> {
                if (c == 'ㅛ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅛ'
                    return true
                } else  if (c == 'ㅚ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅚ'
                    return true
                } else if (c == 'ㅘ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅘ'
                    return true
                }

                return false
            }

            'ㅘ' -> {
                if (c == 'ㅙ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅙ'
                    return true
                }
                return false
            }

            'ㅜ' -> {
                if (c == 'ㅠ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅠ'
                    return true
                } else if (c == 'ㅟ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅟ'
                    return true
                } else {
                    if (c == 'ㅝ') {
                        zulSelFlag = zulSel
                        zulSel = 'ㅝ'
                        return true
                    }
                }

                return false
            }

            'ㅝ' -> {
                if (c == 'ㅞ') {
                    zulSelFlag = zulSel
                    zulSel = 'ㅞ'
                    return true
                }
                return false
            }

            else -> {
                return false
            }
        }
    }

    // 符合跟音
    fun doublezolSelEnable(c: Char): Boolean {
        zolSelFlag = zolSel
        doublezolSelFlag = c
        when (zolSel) {
            'ㄱ' -> {
                if (c == 'ㅅ') {
                    zolSel = 'ㄳ'
                    return true
                }
                return false
            }
            'ㄴ' -> {
                if (c == 'ㅈ') {
                    zolSel = 'ㄵ'
                    return true
                }
                if (c == 'ㅎ') {
                    zolSel = 'ㄶ'
                    return true
                }
                return false
            }
            'ㄹ' -> {
                if (c == 'ㄱ') {
                    zolSel = 'ㄺ'
                    return true
                }
                if (c == 'ㅁ') {
                    zolSel = 'ㄻ'
                    return true
                }
                if (c == 'ㅂ') {
                    zolSel = 'ㄼ'
                    return true
                }
                if (c == 'ㅅ') {
                    zolSel = 'ㄽ'
                    return true
                }
                if (c == 'ㅌ') {
                    zolSel = 'ㄾ'
                    return true
                }
                if (c == 'ㅍ') {
                    zolSel = 'ㄿ'
                    return true
                }
                if (c == 'ㅎ') {
                    zolSel = 'ㅀ'
                    return true
                }
                return false
            }
            'ㅂ' -> {
                if (c == 'ㅅ') {
                    zolSel = 'ㅄ'
                    return true
                }
                return false
            }
            else -> {
                return false
            }
        }
    }

    // 元音状态
    fun zulSelAvailable(): Boolean {
        //   Log.i("CAI", "zulSelAvailable:" + zulSel)
        if (zulSel == 'ㅙ' || zulSel == 'ㅞ' || zulSel == 'ㅢ' || zulSel == 'ㅐ' || zulSel == 'ㅔ' || zulSel == 'ㅛ' || zulSel == 'ㅒ' || zulSel == 'ㅖ') {
            return false
        }
        return true
    }

    fun isDoublezulSel(): Boolean {
        if (zulSel == 'ㅙ' || zulSel == 'ㅞ' || zulSel == 'ㅚ' || zulSel == 'ㅟ' || zulSel == 'ㅢ') {
            //        Log.i("CAI", "isDoublezulSel=T:" + zulSel)
            return true
        }
        //    Log.i("CAI", "isDoublezulSel=F:" + zulSel)
        return false
    }
    //
}